# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import category_category
from . import documents_document
from . import document_review
from . import website
